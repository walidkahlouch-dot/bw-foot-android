package dz.bwfoot.app;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

public class MainActivity extends Activity {

    private WebView webView;
    private ProgressBar progress;

    private static final int NOTIFICATION_PERMISSION = 100;
    private static final String CHANNEL_ID = "bwfoot_downloads";

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

        getWindow().setStatusBarColor(Color.rgb(16, 26, 53));
        getWindow().setNavigationBarColor(Color.rgb(16, 26, 53));

        createNotificationChannel();

        FrameLayout root = new FrameLayout(this);

        webView = new WebView(this);

        progress = new ProgressBar(
                this, null,
                android.R.attr.progressBarStyleHorizontal
        );
        progress.setMax(100);
        progress.setProgressTintList(
                android.content.res.ColorStateList.valueOf(
                        Color.rgb(30, 136, 229)
                )
        );

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportZoom(false);
        settings.setMixedContentMode(
                WebSettings.MIXED_CONTENT_NEVER_ALLOW
        );

        webView.setDownloadListener(
                new DownloadListener() {
                    @Override
                    public void onDownloadStart(
                            String url,
                            String userAgent,
                            String contentDisposition,
                            String mimeType,
                            long contentLength) {

                        downloadFile(
                                url, userAgent,
                                contentDisposition, mimeType
                        );
                    }
                }
        );

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(
                    WebView view,
                    WebResourceRequest request) {

                Uri uri = request.getUrl();
                String host = uri.getHost();

                // Keep direct file/export links inside the app and send them
                // to Android DownloadManager instead of opening a browser.
                if (isLikelyDownloadUrl(uri)) {
                    downloadFile(
                            uri.toString(),
                            null,
                            null,
                            guessMimeType(uri.toString())
                    );
                    return true;
                }

                if (host != null &&
                        (host.equalsIgnoreCase("bw-foot-10.hatchable.site")
                        || host.toLowerCase().endsWith(".hatchable.site"))) {
                    return false;
                }

                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception e) {
                    Toast.makeText(
                            MainActivity.this,
                            "تعذر فتح الرابط",
                            Toast.LENGTH_SHORT
                    ).show();
                }

                return true;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int value) {
                progress.setProgress(value);
                progress.setVisibility(
                        value >= 100 ? View.GONE : View.VISIBLE
                );
            }
        });

        root.addView(
                webView,
                new FrameLayout.LayoutParams(-1, -1)
        );

        FrameLayout.LayoutParams progressParams =
                new FrameLayout.LayoutParams(
                        -1,
                        (int) (3 * getResources()
                                .getDisplayMetrics().density)
                );

        progressParams.gravity = Gravity.TOP;
        root.addView(progress, progressParams);

        setContentView(root);
        requestNotificationPermission();

        if (state != null) {
            webView.restoreState(state);
        }

        if (state == null) {
            webView.loadUrl(
                    "https://bw-foot-10.hatchable.site/"
            );
        }
    }

    private boolean isLikelyDownloadUrl(Uri uri) {
        if (uri == null) return false;
        String path = uri.getPath();
        String lowerPath = path == null ? "" : path.toLowerCase();
        String lowerUrl = uri.toString().toLowerCase();

        String[] extensions = {
                ".pdf", ".png", ".jpg", ".jpeg", ".webp", ".csv",
                ".xlsx", ".xls", ".docx", ".doc", ".zip", ".apk"
        };
        for (String extension : extensions) {
            if (lowerPath.endsWith(extension)) return true;
        }

        return lowerUrl.contains("download=")
                || lowerUrl.contains("attachment=")
                || lowerUrl.contains("/download/")
                || lowerUrl.contains("/export/")
                || lowerUrl.contains("export=");
    }

    private String guessMimeType(String url) {
        String lower = url == null ? "" : url.toLowerCase();
        if (lower.contains(".pdf")) return "application/pdf";
        if (lower.contains(".png")) return "image/png";
        if (lower.contains(".jpg") || lower.contains(".jpeg")) return "image/jpeg";
        if (lower.contains(".webp")) return "image/webp";
        if (lower.contains(".xlsx")) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        if (lower.contains(".xls")) return "application/vnd.ms-excel";
        if (lower.contains(".csv")) return "text/csv";
        if (lower.contains(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        if (lower.contains(".doc")) return "application/msword";
        if (lower.contains(".zip")) return "application/zip";
        return "application/octet-stream";
    }

    private void downloadFile(
            String url,
            String userAgent,
            String contentDisposition,
            String mimeType) {

        try {
            Uri uri = Uri.parse(url);

            if (!"https".equalsIgnoreCase(uri.getScheme())
                    && !"http".equalsIgnoreCase(uri.getScheme())) {
                Toast.makeText(
                        this, "رابط التحميل غير صالح",
                        Toast.LENGTH_LONG
                ).show();
                return;
            }

            DownloadManager.Request request =
                    new DownloadManager.Request(uri);

            String cookies =
                    CookieManager.getInstance().getCookie(url);

            if (cookies != null) {
                request.addRequestHeader("Cookie", cookies);
            }

            if (userAgent != null) {
                request.addRequestHeader("User-Agent", userAgent);
            }

            String fileName = URLUtil.guessFileName(
                    url, contentDisposition, mimeType
            );

            request.setTitle(fileName);
            request.setDescription("تحميل من BW Foot");
            request.setNotificationVisibility(
                    DownloadManager.Request
                            .VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            );
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);

            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    fileName
            );

            DownloadManager manager =
                    (DownloadManager) getSystemService(
                            Context.DOWNLOAD_SERVICE
                    );

            if (manager == null) {
                throw new Exception("DownloadManager unavailable");
            }

            manager.enqueue(request);

            Toast.makeText(
                    this,
                    "بدأ التحميل: " + fileName,
                    Toast.LENGTH_LONG
            ).show();

        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "تعذر بدء التحميل",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel =
                    new NotificationChannel(
                            CHANNEL_ID,
                            "تحميلات BW Foot",
                            NotificationManager.IMPORTANCE_DEFAULT
                    );

            channel.setDescription(
                    "إشعارات تحميل الملفات"
            );

            NotificationManager manager =
                    getSystemService(NotificationManager.class);

            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(
                        Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(
                    new String[]{
                            Manifest.permission.POST_NOTIFICATIONS
                    },
                    NOTIFICATION_PERMISSION
            );
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle bundle) {
        if (webView != null) {
            webView.saveState(bundle);
        }
        super.onSaveInstanceState(bundle);
    }

    @Override
    public boolean onKeyDown(int key, KeyEvent event) {
        if (key == KeyEvent.KEYCODE_BACK
                && webView != null
                && webView.canGoBack()) {
            webView.goBack();
            return true;
        }

        return super.onKeyDown(key, event);
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }

        super.onDestroy();
    }
}
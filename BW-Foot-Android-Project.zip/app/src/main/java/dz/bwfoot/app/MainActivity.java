package dz.bwfoot.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.view.View;
import android.view.KeyEvent;
import android.graphics.Color;
import android.widget.FrameLayout;
import android.widget.ProgressBar;

public class MainActivity extends Activity {
  private WebView webView;
  private ProgressBar progress;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(Color.rgb(16,26,53));
    getWindow().setNavigationBarColor(Color.rgb(16,26,53));
    FrameLayout root = new FrameLayout(this);
    webView = new WebView(this);
    progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
    progress.setMax(100);
    progress.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(30,136,229)));
    WebSettings s = webView.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
    s.setLoadsImagesAutomatically(true); s.setSupportZoom(false);
    s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
    webView.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
        String host = r.getUrl().getHost();
        if (host != null && (host.equals("bw-foot-10.hatchable.site") || host.endsWith(".hatchable.site"))) return false;
        try { startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, r.getUrl())); } catch (Exception ignored) {}
        return true;
      }
    });
    webView.setWebChromeClient(new WebChromeClient() {
      @Override public void onProgressChanged(WebView v, int p) { progress.setProgress(p); progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE); }
    });
    root.addView(webView, new FrameLayout.LayoutParams(-1,-1));
    FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(-1, (int)(3*getResources().getDisplayMetrics().density)); pp.gravity=android.view.Gravity.TOP;
    root.addView(progress, pp); setContentView(root);
    if (state != null) webView.restoreState(state); else webView.loadUrl("https://bw-foot-10.hatchable.site/");
  }
  @Override protected void onSaveInstanceState(Bundle b) { if (webView != null) webView.saveState(b); super.onSaveInstanceState(b); }
  @Override public boolean onKeyDown(int key, KeyEvent e) { if (key == KeyEvent.KEYCODE_BACK && webView != null && webView.canGoBack()) { webView.goBack(); return true; } return super.onKeyDown(key,e); }
  @Override protected void onDestroy() { if (webView != null) { webView.stopLoading(); webView.destroy(); } super.onDestroy(); }
}
